RHADIX TESTBESTANDEN — KIK-V (ONS / Nedap)
===========================================
Bronsysteem: Nedap ONS (referentieontwerp v6.0)
Standaard:   KIK-V

HOE TE GEBRUIKEN
----------------
1. Pak deze ZIP uit zodat alle CSV-bestanden zichtbaar zijn.
2. Open app.rhadix.nl en klik op "Start nieuwe scan".
3. Kies standaard: KIK-V en bronsysteem: ONS.
4. Upload alle CSV-bestanden tegelijk (selecteer ze allemaal).
5. Bekijk het beschikbaarheidsrapport en het dashboard.

INHOUD BESTANDEN
----------------
Werkovereenkomst.csv     → werkovereenkomsten / contracten
Medewerker.csv           → medewerkers / personeel
Verzuim.csv              → verzuimregistraties
Functie.csv              → functies / functieprofiel
(+ overige ONS-tabellen)

OPZETTELIJKE FOUTEN (voor demo/test)
-------------------------------------
De dataset bevat een aantal bewuste fouten zodat de validator
ook waarschuwingen en foutmeldingen toont. Dit is normaal gedrag.

Vragen? info@rhadix.nl
