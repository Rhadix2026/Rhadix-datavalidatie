Rhadix — ONS testbestanden
==========================

Inhoud van dit pakket (Nedap ONS CSV-exports, 15 medewerkers):

  ONS_Employees.csv     — Medewerkers (Person + Employee combined)
  ONS_Contracts.csv     — Contracten
  ONS_PresenceLog.csv   — Aanwezigheidsregistratie
  ONS_Absences.csv      — Verzuim
  ONS_Teams.csv         — Teams

Gebruik
-------
1. Kies in Rhadix "Beschikbaarheid Algemeen"
2. Upload één of meerdere CSV-bestanden uit dit pakket
3. Rhadix detecteert automatisch het bestandstype en voert de pre-scan uit

Veldnamen volgen de Nedap ONS OpenAPI-spec (camelCase).
BSN-nummers zijn fictief maar voldoen aan de elfproef.
