RHADIX TESTBESTANDEN — ZIB (Zorginformatiebouwstenen)
=====================================================
Standaard: ZIB (FHIR-gebaseerde zorginformatiebouwstenen)

HOE TE GEBRUIKEN
----------------
1. Pak deze ZIP uit zodat alle CSV-bestanden zichtbaar zijn.
2. Open app.rhadix.nl en klik op "Start nieuwe scan".
3. Kies standaard: ZIB.
4. Upload alle CSV-bestanden tegelijk (selecteer ze allemaal).
5. Bekijk het ZIB-dashboard met beschikbaarheids- en actualiteitsscores.

INHOUD BESTANDEN
----------------
patient.csv              → patiëntgegevens (ZIB Patient)
probleem.csv             → diagnoses / problemen (ZIB Probleem)
medicatieafspraak.csv    → medicatieafspraken (ZIB MedicatieAfspraak)
allergie.csv             → allergieën / intoleranties (ZIB AllergiéIntolerantie)

Vragen? info@rhadix.nl
